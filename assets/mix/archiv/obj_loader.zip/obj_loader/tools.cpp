

/*
  // Загрузка из Obj файла объекта "несколько-снипов/один-риг":
  tr::obj_load Obj = {"../assets/test_flat.obj"};
  tr::f3d P = {1.f, 0.f, 1.f};
  for(auto &S: Obj.Area) S.point_set(P); // Установить объект в точке P
  get(P)->Area.swap(Obj.Area);           // Загрузить в rig(P)
*/


//## Загрузка данных из Obj файла (заданного в коде функции)
void load_16x16_obj(void)
{
/// Загруженые данные представляют из себя поверхность 16х16 прямоугольников,
/// расположенную в центре оси кординат. Все прямоугольники проецируются в
/// горизонтальные квадраты со стороной 1.0f. Соответственно из каждого
/// формируется отдельный риг с одним снипом.
///
/// Поверхность формируется в виде поля 8*8 путем дублирования 64 раза по
/// горизонтальным координатам X и Z, загруженый из файла фрагмент 16*16 снипов.

  tr::obj_load Obj = {"../assets/surf16x16.obj"};

  tr::i3d Base = {0, 0, 0};
  tr::i3d Pt   = {0, 0, 0};

  for (int z = -4; z < 4; z ++)
  {
    Base.z = z * 16 + 8;

  for (int x = -4; x < 4; x ++)
  {
    Base.x = x * 16 + 8;

    for(tr::snip S: Obj.Area)
    {
      size_t n = 0;
      // В снипе 4 вершины, индекс опорной выбираем по минимальному значению длины
      for(size_t i = 1; i < 4; i++)
        if((
             S.data[n * ROW_STRIDE + COORD_X]
           + S.data[n * ROW_STRIDE + COORD_Y]
           + S.data[n * ROW_STRIDE + COORD_Z]
              ) > (
             S.data[i * ROW_STRIDE + COORD_X]
           + S.data[i * ROW_STRIDE + COORD_Y]
           + S.data[i * ROW_STRIDE + COORD_Z]
           )) n = i;

      // Координаты найденой вершины используем для создания рига,
      // к которому и привяжем текущий снип
      Pt.x = static_cast<int>( floor(S.data[n * ROW_STRIDE + COORD_X]) ) + Base.x;
      Pt.y = static_cast<int>( floor(S.data[n * ROW_STRIDE + COORD_Y]) ) + Base.y;
      Pt.z = static_cast<int>( floor(S.data[n * ROW_STRIDE + COORD_Z]) ) + Base.z;

      S.point_set(Pt);
      tr::rig R = {};
      R.Trick.push_front(S);
      Db[Pt] = R;
    }
  } //for x
  } //for z

  // Выделить текстурой центр координат
  get(0,0,0 )->Trick.front().texture_set(0.125, 0.125 * 4.0);

  return;
}


